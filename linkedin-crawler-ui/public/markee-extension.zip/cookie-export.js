(function () {
  "use strict";

  const EXPORT_UI_ID = "fbCookieExportTools";
  const STATUS_ID = "fbCookieExportStatus";

  function getAllCookies(details) {
    if (!window.chrome || !chrome.cookies || !chrome.cookies.getAll) {
      throw new Error("Ban dang mo popup bang web/localhost. Hay bam icon extension tren Chrome hoac mo chrome-extension://.../popup.html de xuat cookie.");
    }

    return new Promise((resolve, reject) => {
      chrome.cookies.getAll(details, (cookies) => {
        const err = chrome.runtime.lastError;
        if (err) {
          reject(new Error(err.message || "Cannot read cookies"));
          return;
        }
        resolve(cookies || []);
      });
    });
  }

  function toPlaywrightCookie(cookie) {
    const sameSiteMap = {
      no_restriction: "None",
      lax: "Lax",
      strict: "Strict",
    };
    const exported = {
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain,
      path: cookie.path || "/",
      expires: cookie.expirationDate ? Math.floor(cookie.expirationDate) : -1,
      httpOnly: Boolean(cookie.httpOnly),
      secure: Boolean(cookie.secure),
    };
    const sameSite = sameSiteMap[cookie.sameSite];
    if (sameSite) exported.sameSite = sameSite;
    return exported;
  }

  async function readFacebookCookies() {
    const cookies = await getAllCookies({ domain: ".facebook.com" });
    const cUser = cookies.find((cookie) => cookie.name === "c_user");

    if (!cUser || !cUser.value || cUser.value === "0") {
      throw new Error("Chua thay cookie c_user. Hay dang nhap facebook.com truoc.");
    }

    const normalized = cookies
      .map(toPlaywrightCookie)
      .sort((a, b) => `${a.domain}:${a.name}`.localeCompare(`${b.domain}:${b.name}`));

    return {
      type: "facebook-cookies",
      format: "playwright",
      fb_user_id: cUser.value,
      cookie_count: normalized.length,
      captured_at: new Date().toISOString(),
      cookies: normalized,
    };
  }

  function buildCookieHeader(cookies) {
    return cookies
      .filter((cookie) => cookie.name && cookie.value)
      .map((cookie) => `${cookie.name}=${cookie.value}`)
      .join("; ");
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch (err) {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.setAttribute("readonly", "readonly");
      textarea.style.position = "fixed";
      textarea.style.left = "-9999px";
      document.body.appendChild(textarea);
      textarea.select();
      const ok = document.execCommand("copy");
      textarea.remove();
      if (!ok) throw err;
    }
  }

  function downloadText(filename, content, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function setStatus(message, ok) {
    const status = document.getElementById(STATUS_ID);
    if (!status) return;
    status.textContent = message;
    status.style.color = ok ? "#16a34a" : "#dc2626";
  }

  function setBusy(button, busy) {
    if (!button) return;
    button.disabled = busy;
    button.style.opacity = busy ? "0.6" : "1";
  }

  async function withCookies(button, onCookies) {
    setBusy(button, true);
    setStatus("Dang doc cookie Facebook...", true);
    try {
      const payload = await readFacebookCookies();
      await onCookies(payload);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "Khong xuat duoc cookie.", false);
    } finally {
      setBusy(button, false);
    }
  }

  function createButton(id, text) {
    const button = document.createElement("button");
    button.id = id;
    button.className = "save-btn";
    button.type = "button";
    button.textContent = text;
    button.style.marginTop = "8px";
    return button;
  }

  function installUi() {
    if (document.getElementById(EXPORT_UI_ID)) return;

    const anchor = document.getElementById("copyVpsHandoff") || document.getElementById("syncSession");
    if (!anchor || !anchor.parentElement) return;

    const wrap = document.createElement("div");
    wrap.id = EXPORT_UI_ID;
    wrap.style.marginTop = "14px";
    wrap.style.borderTop = "1px dashed #d0d4dd";
    wrap.style.paddingTop = "10px";

    const title = document.createElement("div");
    title.textContent = "Xuat cookie Facebook";
    title.style.fontSize = "12px";
    title.style.color = "#444";
    title.style.fontWeight = "700";
    title.style.marginBottom = "4px";

    const note = document.createElement("div");
    note.textContent = "Cookie la phien dang nhap. Chi copy vao noi ban tin cay.";
    note.style.fontSize = "11px";
    note.style.color = "#666";
    note.style.lineHeight = "1.45";
    note.style.marginBottom = "2px";

    const contextNote = document.createElement("div");
    contextNote.textContent = window.chrome && chrome.cookies && chrome.cookies.getAll
      ? "Dang chay trong extension context."
      : "Ban dang mo bang web/localhost nen Chrome khong cap quyen doc cookie.";
    contextNote.style.fontSize = "11px";
    contextNote.style.color = window.chrome && chrome.cookies && chrome.cookies.getAll ? "#15803d" : "#dc2626";
    contextNote.style.lineHeight = "1.45";
    contextNote.style.marginBottom = "2px";

    const copyJson = createButton("copyFbCookiesJson", "Copy JSON cookie");
    const copyHeader = createButton("copyFbCookieHeader", "Copy Cookie header");
    copyHeader.style.background = "linear-gradient(135deg,#0f766e,#14b8a6)";
    const downloadJson = createButton("downloadFbCookiesJson", "Tai cookies.json");
    downloadJson.style.background = "linear-gradient(135deg,#4f46e5,#6366f1)";

    const status = document.createElement("div");
    status.id = STATUS_ID;
    status.style.fontSize = "12px";
    status.style.marginTop = "6px";

    wrap.appendChild(title);
    wrap.appendChild(note);
    wrap.appendChild(contextNote);
    wrap.appendChild(copyJson);
    wrap.appendChild(copyHeader);
    wrap.appendChild(downloadJson);
    wrap.appendChild(status);
    anchor.parentElement.insertBefore(wrap, anchor.nextSibling);

    copyJson.addEventListener("click", () => withCookies(copyJson, async (payload) => {
      await copyText(JSON.stringify(payload, null, 2));
      setStatus(`Da copy JSON ${payload.cookie_count} cookie (FB UID: ${payload.fb_user_id}).`, true);
    }));

    copyHeader.addEventListener("click", () => withCookies(copyHeader, async (payload) => {
      await copyText(buildCookieHeader(payload.cookies));
      setStatus(`Da copy Cookie header ${payload.cookie_count} cookie.`, true);
    }));

    downloadJson.addEventListener("click", () => withCookies(downloadJson, async (payload) => {
      const content = JSON.stringify(payload, null, 2);
      downloadText(`facebook-cookies-${payload.fb_user_id}.json`, content, "application/json;charset=utf-8");
      setStatus(`Da tai file JSON ${payload.cookie_count} cookie.`, true);
    }));
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", installUi);
  } else {
    installUi();
  }
})();
